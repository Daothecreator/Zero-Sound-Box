"use client";

import { useEffect } from "react";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-black text-white p-4">
      <h2 className="text-2xl mb-4 text-red-500">Something went wrong!</h2>
      <button
        className="px-4 py-2 bg-white/10 rounded-md"
        onClick={() => reset()}
      >
        Try again
      </button>
    </div>
  );
}
